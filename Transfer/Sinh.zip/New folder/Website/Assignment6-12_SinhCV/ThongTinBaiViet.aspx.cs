﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entities;
using Business;

public partial class ThongTinBaiViet : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string idBaiViet = Request.QueryString["IdBaiViet"];
        Session["IdBaiViet"] = idBaiViet;
        if (Session["Login"] != null)
        {
            txtUser.Text = Session["Login"].ToString();
            pnLogin.Visible = false;
            pnLogout.Visible = true;
        }

        if (!Page.IsPostBack)
        {
        }
        getBaiviet(idBaiViet);
    }

    public void getBaiviet(string idBaiViet)
    {
        BaiViet bv = Business.AccountBu.BaiVietId(idBaiViet);
        txtTieuDe.Text = bv.TieuDe;
        Img1.ImageUrl = bv.LinkImage;
        txtNoiDung.Text = bv.NoiDung;



    }
   
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (AccountBu.CheckLogin(txtUsername.Text, txtPassword.Text))
        {
            this.Session["Login"] = txtUsername.Text;
            txtUser.Text = Session["Login"].ToString();
            pnLogin.Visible = false;
            pnLogout.Visible = true;
            Response.Redirect("HomePage.aspx");
        }
        else
        {

        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Remove("Login");
        pnLogin.Visible = true;
        pnLogout.Visible = false;
        Response.Redirect("HomePage.aspx");
    }


}
