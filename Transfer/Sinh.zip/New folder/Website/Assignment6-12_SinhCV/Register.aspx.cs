﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entities;
using Business;

public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Login"] != null)
        {
            txtUser.Text = Session["Login"].ToString();
            pnLogin.Visible = false;
            pnLogout.Visible = true;
        }
    }
    protected void btnOK_Click(object sender, EventArgs e)
    {
        User user = new User(txtUsername.Text,txtPassword.Text);
        AccountBu ac = new AccountBu();
        if (txtConfirm.Text == txtPassword.Text)
        {
            ac.InserU(user);
           Response.Write("<script>alert('Sucessfull!!!')</script>");
           Clear();
           Response.Redirect("HomePage.aspx");
        }
        else
        {
            
        }
    }

    public void Clear()
    {
        txtConfirm.Text = string.Empty;
        txtUsername.Text = string.Empty;
        txtPassword.Text = string.Empty;
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (AccountBu.CheckLogin(txtUsername.Text, txtPassword.Text))
        {
            this.Session["Login"] = txtUsername.Text;
            txtUser.Text = Session["Login"].ToString();
            pnLogin.Visible = false;
            pnLogout.Visible = true;
            Response.Redirect("HomePage.aspx");
        }
        else
        {

        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Remove("Login");
        pnLogin.Visible = true;
        pnLogout.Visible = false;
        Response.Redirect("HomePage.aspx");
    }
}