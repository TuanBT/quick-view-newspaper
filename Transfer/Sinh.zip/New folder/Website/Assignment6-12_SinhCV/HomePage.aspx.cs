﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using Business;
using DataAccess;

public partial class HomePage : System.Web.UI.Page
{
    //DataProvider data = new DataProvider();

    protected void Page_Load(object sender, EventArgs e)
    {
        if(Session["Login"] != null)
        {
            txtUser.Text = Session["Login"].ToString();
            pnLogin.Visible = false;
            pnLogout.Visible = true;
        }

        if (!Page.IsPostBack)
        {
            GetData();
            GetAType();
        }

    }

    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (AccountBu.CheckLogin(txtUsername.Text, txtPassword.Text))
        {
            this.Session["Login"] = txtUsername.Text;
            txtUser.Text = Session["Login"].ToString();
            pnLogin.Visible = false;
            pnLogout.Visible = true;
            Response.Redirect("HomePage.aspx");
        }
        else
        {
  
        }
    }

    private void GetData()
    {
        
        CollectionPager1.MaxPages = 10;
        CollectionPager1.PageSize = 3;
        CollectionPager1.DataSource = Business.AccountBu.GetAllPost();
        CollectionPager1.BindToControl = DataList1;
        DataList1.DataSource = CollectionPager1.DataSourcePaged;
        DataList1.DataBind();
    }

    private void GetAType()
    {
        DataList2.DataSource = Business.AccountBu.GetAllType();
        DataList2.DataBind();
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Remove("Login");
        pnLogin.Visible = true;
        pnLogout.Visible = false;
        Response.Redirect("HomePage.aspx");
    }
}