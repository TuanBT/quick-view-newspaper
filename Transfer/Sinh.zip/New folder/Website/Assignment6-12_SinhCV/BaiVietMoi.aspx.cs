﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccess;
using Entities;
using Business;
using System.Data;

public partial class BaiVietMoi : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string idBaiViet = Request.QueryString["IdBaiViet"];
        Session["IdBaiViet"] = idBaiViet;
        if (Session["Login"] != null)
        {
            txtUser.Text = Session["Login"].ToString();
            pnLogin.Visible = false;
            pnLogout.Visible = true;
        }

        if (!Page.IsPostBack)
        {
           Drop();
        }
        getBaiviet(idBaiViet);
    }

    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (AccountBu.CheckLogin(txtUsername.Text, txtPassword.Text))
        {
            this.Session["Login"] = txtUsername.Text;
            txtUser.Text = Session["Login"].ToString();
            pnLogin.Visible = false;
            pnLogout.Visible = true;
        }
        else
        {

        }
    }
    public void Drop()
    {
        DropDownList1.DataSource = Business.AccountBu.GetAllType();
        DropDownList1.DataTextField = "TenTheLoai";
        DropDownList1.DataBind();
    }

    public string getday()
    {
        string Date = DateTime.Now.ToString("u");
        return Date.Replace("Z","");
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Remove("Login");
        pnLogin.Visible = true;
        pnLogout.Visible = false;
    }
    protected void btnInsert_Click(object sender, EventArgs e)
    {
        Random rd = new Random();
        Entities.TheLoai theLoai = new TheLoai();
        Entities.BaiViet baiViet = new BaiViet();
        baiViet.TieuDe = txtTitle.Text;
        baiViet.NoiDung = ckContent.Text;
        baiViet.NgayTao = getday();
        theLoai.TenTheLoai = DropDownList1.Text;



        baiViet.IdTheLoai = rd.Next(1, 3).ToString();
        baiViet.LinkImage = txtImage.Text;
        if(Business.AccountBu.InserB(theLoai,baiViet))
        {
            
        }

    }


    public void getBaiviet(string idBaiViet)
    {
        BaiViet bv = Business.AccountBu.BaiVietId(idBaiViet);
        txtTitle.Text = bv.TieuDe;
        //Img1.ImageUrl = bv.LinkImage;
        ckContent.Text = bv.NoiDung;



    }
}