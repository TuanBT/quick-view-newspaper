﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace Commons
{
    public static class AppConfig
    {
        /// <summary>
        /// Chuoi ket noi
        /// </summary>
        public static string ConnectionString
        {
            get
            {
                ConnectionStringSettings conSetting = ConfigurationManager.ConnectionStrings["myConnectionString"];
                return conSetting.ConnectionString;
            }
        }
    }
}
