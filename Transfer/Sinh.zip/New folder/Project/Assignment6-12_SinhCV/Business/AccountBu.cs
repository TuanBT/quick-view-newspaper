﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess;
using Entities;

namespace Business
{
    public class AccountBu
    {
        Account account = new Account();
        

        public static bool CheckLogin(string username,string password)
        {
            return Account.CheckLogin(username, password);
        }

       public static List<BaiViet> GetAllPost()
       {
           Account account = new Account();
           return account.GetAllPost();
       }

        public static List<TheLoai> GetAllType()
        {
            Account account = new Account();
            return account.GetAType();
        }
        public void InserU(User user)
        {
           
           account.InsertUser(user);
        }

        public static bool InserB(TheLoai theLoai, BaiViet baiViet)
        {
            Account account = new Account();

            return account.Insert(theLoai, baiViet);
            //Account account = new Account();
            //return account.Insert(user);
        }

        public static  BaiViet BaiVietId(string idBaiViet)
        {
            Account account = new Account();
            return account.GetIdPost(idBaiViet);
        }
    }
}
