﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Entities
{
    public class TheLoai
    {
        public string IdTheLoai { get; set; }
        public string TenTheLoai { get; set; }
        public string MoTa { get; set; }
        public string Active { get; set; }

        /// <summary>
        /// Nap du lieu vao bien
        /// </summary>
        /// <param name="dataReader"></param>
        /// <returns></returns>
        public TheLoai LDataReader(IDataReader dataReader)
        {
            TheLoai theLoai = new TheLoai();
            theLoai.IdTheLoai = (dataReader["idTheLoai"] is DBNull) ? string.Empty : dataReader["idTheLoai"].ToString();
            theLoai.TenTheLoai = (dataReader["tenTheLoai"] is DBNull) ? string.Empty : dataReader["tenTheLoai"].ToString();
            theLoai.MoTa = (dataReader["moTa"] is DBNull) ? string.Empty : dataReader["moTa"].ToString();
            theLoai.Active = (dataReader["active"] is DBNull) ? string.Empty : dataReader["active"].ToString();
            return theLoai;
        }
    }
   
}
