﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entities
{
    class Comment
    {
        public int IdComment { get; set; }
        public string NoiDung { get; set; }
        public string NgayComment { get; set; }       
    }
}
