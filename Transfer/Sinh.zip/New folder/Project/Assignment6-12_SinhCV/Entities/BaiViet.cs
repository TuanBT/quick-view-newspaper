﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Entities
{
    public class BaiViet
    {
        public string IdBaiViet { get; set; }
        public string Id { get; set; }
        public string IdTheLoai { get; set; }
        public string TieuDe { get; set; }
        public string NoiDung { get; set; }
        public string LinkImage { get; set; }
        public string NgayTao { get; set; }       

        /// <summary>
        /// Nap du lieu vao bien
        /// </summary>
        /// <param name="dataReader"></param>
        /// <returns></returns>
        public BaiViet PostDataReader(IDataReader dataReader)
        {
            BaiViet baiViet = new BaiViet();
            baiViet.IdBaiViet = (dataReader["idBaiViet"] is DBNull) ? string.Empty : dataReader["idBaiViet"].ToString();
            baiViet.Id = (dataReader["id"] is DBNull) ? string.Empty : dataReader["id"].ToString();
            baiViet.IdTheLoai = (dataReader["idTheLoai"] is DBNull) ? string.Empty : dataReader["idTheLoai"].ToString();
            baiViet.TieuDe = (dataReader["tieuDe"] is DBNull) ? string.Empty : dataReader["tieuDe"].ToString();
            baiViet.NoiDung = (dataReader["noiDung"] is DBNull) ? string.Empty : dataReader["noiDung"].ToString();
            baiViet.LinkImage = (dataReader["linkImage"] is DBNull) ? string.Empty : dataReader["linkImage"].ToString();
            baiViet.NgayTao = (dataReader["ngayTao"] is DBNull) ? string.Empty : dataReader["ngayTao"].ToString();
            return baiViet;
            
        }
    }
}
