﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using Commons;

namespace DataAccess
{
    public class Data
    {
        
        /// <summary>
        /// Tao ket noi
        /// </summary>
        /// <returns></returns>
        public static SqlConnection get()
        {
            SqlConnection con = new SqlConnection(AppConfig.ConnectionString);
            return con;
        }

    }
}
