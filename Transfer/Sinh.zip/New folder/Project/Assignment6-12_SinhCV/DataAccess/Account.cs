﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using Commons;
using System.Data;
using Entities;

namespace DataAccess
{
    public class Account
    {
        private SqlDataReader sdr = null;
        private SqlCommand cmd = null;
        
        /// <summary>
        /// Kiem tra login
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public static bool CheckLogin(string username, string password)
        {
            SqlConnection con = Data.get();
            con.Open();
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM tblAccount Where username='"+ username +"'AND password='"+ password +"'", con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    return true;
                }
            }
            catch (Exception)
            {
                
                throw;
            }
            
            return false;
        }
       
        /// <summary>
        /// Doc du lieu tat ca bai viet tu database
        /// </summary>
        /// <returns></returns>
        public List<BaiViet> GetAllPost()
        {
            SqlConnection con = Data.get();
            con.Open();
            List<BaiViet> listBaiViet = new List<BaiViet>();
            BaiViet baiViet = new BaiViet();
            cmd = new SqlCommand("SELECT * FROM tblBaiViet b, tblTheLoai t, tblAccount a WHERE a.Id = b.Id AND b.idTheloai = t.idTheloai ", con);
            try
            {
                sdr = cmd.ExecuteReader();
                //Neu co du lieu
                if (sdr.HasRows)
                {
                    //trong khi con doc
                    while (sdr.Read())
                    {
                        listBaiViet.Add(baiViet.PostDataReader(sdr));
                    }
                }
                sdr.Close();
                return listBaiViet;
            }
            catch (Exception)
            {
                    
                throw;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
           
        }

        /// <summary>
        /// Lay id cua bai viet
        /// </summary>
        /// <param name="idBaiViet"></param>
        /// <returns></returns>
        public BaiViet GetIdPost(string idBaiViet)
        {
            SqlConnection con = Data.get();
            con.Open();
            BaiViet baiViet = new BaiViet();
            SqlDataAdapter catDA = new SqlDataAdapter("SELECT * FROM tblBaiViet  b, tblTheLoai t WHERE idBaiViet ='" + idBaiViet + "' AND b.idTheLoai = t.idTheLoai " , con);
            DataSet catDS = new DataSet();
            catDA.Fill(catDS);
            //Duyet tung dong trong database
            foreach (DataRow ro in catDS.Tables[0].Rows)
            {
                baiViet.IdBaiViet = ro["idBaiViet"].ToString();
                baiViet.TieuDe = ro["tieuDe"].ToString();
                baiViet.NoiDung = ro["noiDung"].ToString();
                baiViet.LinkImage = ro["linkImage"].ToString();
                baiViet.NgayTao = ro["ngayTao"].ToString();
            }
            return baiViet;
        }

        /// <summary>
        /// Doc du lieu cua tat ca the loai trong database
        /// </summary>
        /// <returns></returns>
        public List<TheLoai> GetAType()
        {
            SqlConnection con = Data.get();
            con.Open();
            List<TheLoai> listTheLoai = new List<TheLoai>();
             cmd = new SqlCommand("SELECT * FROM tblTheLoai",con);
            TheLoai theLoai = new TheLoai();
            try
            {
                sdr = cmd.ExecuteReader();
                //Neu co du lieu
                if (sdr.HasRows)
                {
                    //trong khi con doc
                    while (sdr.Read())
                    {
                        listTheLoai.Add(theLoai.LDataReader(sdr));
                    }
                }
                sdr.Close();
                return listTheLoai;
            }
            catch (Exception)
            {
                
                throw;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            

        }

        //lay id the loai
        public TheLoai GetIdTheLoai()
        {
            SqlConnection con = Data.get();
            con.Open();
            TheLoai theLoai = new TheLoai();
            SqlDataAdapter catDA = new SqlDataAdapter("SELECT idTheLoai FROM tblTheLoai WHERE tenTheLoai = 'SmartPhone' OR tenTheLoai='Tablet' OR tenTheLoai='Computer'", con);
            DataSet catDS = new DataSet();
            catDA.Fill(catDS);
            foreach (DataRow ro in catDS.Tables[0].Rows)
            {
                theLoai.IdTheLoai = ro["idTheLoai"].ToString();
                theLoai.TenTheLoai = ro["tenTheLoai"].ToString();
            }
            return theLoai;
        }

        /// <summary>
        /// Inser bai viet moi
        /// </summary>
        /// <param name="theLoai"></param>
        /// <param name="baiViet"></param>
        /// <returns></returns>
        public bool Insert(TheLoai theLoai, BaiViet baiViet)
        {
            SqlConnection con = Data.get();
            con.Open();
            SqlCommand cm = new SqlCommand("INSERT INTO [tblBaiViet] (idTheloai,linkImage,ngayTao,noiDung,tieuDe) VALUES" +
                                           "('"+baiViet.IdTheLoai+"','"+baiViet.LinkImage+"','"+baiViet.NgayTao+"','"+baiViet.NoiDung+"','"+baiViet.TieuDe+"')", con);
            try
            {
                cm.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                
                throw;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
        }

        /// <summary>
        /// Inser user moi
        /// </summary>
        /// <param name="user"></param>
        public void InsertUser(User user)
        {
            SqlConnection con = Data.get();
            con.Open();
            String sql = "INSERT INTO tblAccount VALUES ('" + user.UserName + "','" + user.Password + "')";
            SqlCommand cmd = new SqlCommand(sql,con);
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                
                throw;
            }
            finally
            {
                if(con != null)
                {
                    con.Close();
                }
            }
        }

    }
}
